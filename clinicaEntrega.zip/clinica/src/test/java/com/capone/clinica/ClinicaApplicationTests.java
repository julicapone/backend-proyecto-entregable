package com.capone.clinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
